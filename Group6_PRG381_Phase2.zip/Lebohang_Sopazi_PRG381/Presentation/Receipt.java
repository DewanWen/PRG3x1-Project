package Presentation;
import java.io.FileNotFoundException;
import Data_Access.Datahandler;
import Data_Access.Logister;

public class Receipt{

    public static void main(String[] args) throws FileNotFoundException {
        Logister dh = new Logister();
        dh.display();
    }

}