package Data_Access;

import java.io.FileNotFoundException;
import java.util.Scanner;

public class Register {
    // //fields
    public String Name;
    public String Surname;
    public Integer Phone_Number;
    public Integer Number;
    public String Email;
    public String Password;

   
    // verify the email
    public String verifyEmail(String Email) {

        Scanner sc = new Scanner(System.in);

        while (!Email.contains("@")) {

            System.out.println("Incorrect email format");
            System.out.println("We will need your email when contacting you, please make sure it is correct");

            System.out.println("Please enter your email: ");
            System.out.println("\n");

            Email = sc.next();

        }

        return Email;

    }

    public void Details() throws FileNotFoundException {

        Scanner sc = new Scanner(System.in);

        // captures the name
        System.out.println("Please enter your name: ");
        Name = sc.next();

        // captures the surname
        System.out.println("Please enter your surname: ");
        Surname = sc.next();

        // captures the phone number
        System.out.println("Please enter your phone number: ");
        Number = sc.nextInt();

        // verify 10 digit number
        Phone_Number = verifyNumber(Number);

        // captures the email
        System.out.println("Please enter your email: ");
        Email = sc.next();

        // verifies email
        Email = verifyEmail(Email);

        // captures the password
        System.out.println("Please enter your password: ");
        Password = sc.next();

        System.out.println("\n-----------------------------------------------------------------");

        // verifies if registration occured
        Logister lo = new Logister();
        lo.Log();

    }

    // once the email has been verified then we can only add it to excel
    public Integer verifyNumber(Integer Phone_Number) {

        String digits = Phone_Number.toString();

        while (digits.length() != 9) {

            Scanner no = new Scanner(System.in);
            System.out.println("Please enter a 10 digit number");

            System.out.println("We will need this number when contacting you, please make sure it is correct");
            Phone_Number = no.nextInt();

            digits = Phone_Number.toString();

        }

        return Integer.parseInt(digits);

    }

    public void setName(String name){
        this.Name=name;
    }
    
    public String getName(String name) {
        return name;
    }
    

}
