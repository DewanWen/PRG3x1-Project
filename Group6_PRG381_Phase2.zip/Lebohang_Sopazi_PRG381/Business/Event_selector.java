package Business;

import java.util.Scanner;

public class Event_selector {

    //

    public void Men() {

        // user choice
        Scanner choice = new Scanner(System.in);

        System.out.println("\n-------------------------------------------\n");
        System.out.println("-----------------------------------------------");
        System.out.println("Please select the type of event you are booking us for: ");
        System.out.println("\n");
        System.out.println("1. Baptism. \n2. Birthday party. \n3. Wedding. \n4. Year end function \n5. Other");
        System.out.println("\n");

        Integer sc = choice.nextInt();

        if (sc == 1) {

            // instance of the class
            Baptism bapt = new Baptism();
            bapt.questions();

        } else if (sc == 2) {

            // birthday
            //Birthday birth = new Birthday();
            //birth.questions();

        } else if (sc == 3) {

            // wedding
            //Wedding wed = new Wedding();
            //wed.questions();

        } else if (sc == 4) {

            // Year end function
            //yearEndFunction yef = new yearEndFunction();
            //yef.questions();

        } else if (sc == 5) {
            // Other
            //Other ot = new Other();
            //ot.questions();
        }

    }

}
