package Business;

import Data_Access.Datahandler;
import Data_Access.Logister;
import Data_Access.Register;
import java.util.*;

public class Printing {
    // printing a receipt here
    // we need to instantiate the classes that we will be using to print the receipt

    // intances of classes here
    Calculation ca = new Calculation();// this will tell how much is due

    Integer custnumber;
    Random rn = new Random();
    String type;
    Integer Capacity;
    Double Balance;
    String Nnamee;

    String company = "Delicious-Catering";

    // important classes
    Baptism bp = new Baptism();
    /*Birthday bi = new Birthday();
    Wedding we = new Wedding();
    yearEndFunction ye = new yearEndFunction();
    Other ot = new Other();*/
    Register lo = new Register();
    Logister lo2 = new Logister();

    // this method gets fields from baptism class
    public void frombaptism() {

        // here we design how the invoive will look like
        Date date = new Date();

        custnumber = rn.nextInt(1000);

        // printing the receipt

        System.out.println(company.toUpperCase() + "\t" + "Cust" + custnumber);
        System.out.println("------------------------------------------------------------");
        System.out.println(" Name: " + Nnamee);
        System.out.println(" Surname: " + lo.Surname);
        System.out.println(" Phone number: " + lo.Number);
        System.out.println(" Email: " + lo.Email);
        System.out.println("\n-------------------------------------------------------------");
        System.out.println(" Type: " + "\t" + " Venue: " + "\t" + " Date: " + "\t" + " Time: " + "\t");
        System.out.println("----------------------------------------------------------------");
        System.out.println(bp.eventType + "\t" + bp.venue + "\t" + bp.Event_Date + "\t" + bp.Time);
        System.out.println(" Capacity: " + Capacity);
        System.out.println("+---------------------------------------------------------------");
        System.out.println(" Printed on: " + "\t\t" + date);
        System.out.println("---------------------------------------------------------------");
        System.out.println("Please keep the receipt as proof of booking and payment. ");
        System.out.println("---------------------------------------------------------------");

        //
    }

    public void extract(String a){
        this.Nnamee = a;
    }

    /*public void fromBirthd() {
        // here we design how the invoive will look like
        Date date = new Date();

        custnumber = rn.nextInt(1000);

        // printing the receipt

        System.out.println(company.toUpperCase() + "\t\t" + "Cust" + custnumber);
        System.out.println("+---------------------------------------------------------------\n");
        System.out.println("_Name: " + lo.Name);
        System.out.println("_Surname: " + lo.Surname);
        System.out.println("_Phone number: " + lo.Number);
        System.out.println("_Email: " + lo.Email);
        System.out.println("\n----------------------------+---------------------------------\n");
        System.out.println("_Type: " + "\t" + "_Venue: " + "\t" + "_Date: " + "\t" + "_Time: " + "\t");
        System.out.println("------------------------------------------+-----------------------");
        System.out.println(type + "\t" + bi.venue + "\t" + bi.Event_Date + "\t" + bi.Time);
        System.out.println("_Capacity: " + Capacity);
        System.out.println("\n--------------------------------+-------------------------------\n");
        System.out.println("_Printed on: " + "\t\t" + date);
        System.out.println("\n---------------------------------------------------+------------\n");
        System.out.println("Please keep the receipt as proof of booking and payment. ");
        System.out.println("\n-------------+--------------------------------------------------");

        //
    }

    public void fromwedding() {
        // here we design how the invoive will look like
        Date date = new Date();

        custnumber = rn.nextInt(1000);

        // printing the receipt

        System.out.println(company.toUpperCase() + "\t\t" + "Cust" + custnumber);
        System.out.println("+---------------------------------------------------------------\n");
        System.out.println(".Name: " + lo.Name);
        System.out.println(".Surname: " + lo.Surname);
        System.out.println(".Phone number: " + lo.Number);
        System.out.println(".Email: " + lo.Email);
        System.out.println("\n+-------------------------------------------------------------\n");
        System.out.println(".Type: " + "\t" + ".Venue: " + "\t" + ".Date: " + "\t" + ".Time: " + "\t");
        System.out.println("+-----------------------------------------------------------------");
        System.out.println(type + "\t" + we.venue + "\t" + we.Event_Date + "\t" + we.Time);
        System.out.println(".Capacity: " + Capacity);
        System.out.println("\n+---------------------------------------------------------------\n");
        System.out.println(".Printed on: " + "\t\t\t\t\t" + date);
        System.out.println("\n+---------------------------------------------------------------\n");
        System.out.println(".Please keep the receipt as proof of booking and payment.");
        System.out.println("\n+---------------------------------------------------------------");

        //
    }

    public void fromOther() {
        // here we design how the invoive will look like
        Date date = new Date();

        custnumber = rn.nextInt(1000);

        // printing the receipt

        System.out.println(company.toUpperCase() + "\t\t\t\t" + "Cust" + custnumber);
        System.out.println("---------------------------------------------------------------\n");
        System.out.println("Name: " + lo.Name);
        System.out.println("Surname: " + lo.Surname);
        System.out.println("Phone number: " + lo.Number);
        System.out.println("Email: " + lo.Email);
        System.out.println("\n-------------------------------------------------------------\n");
        System.out.println("Type: " + "\t" + "Venue: " + "\t" + "Date: " + "\t" + "Time: " + "\t");
        System.out.println("-----------------------------------------------------------------");
        System.out.println(type + "\t" + ot.venue + "\t" + ot.Event_Date + "\t" + ot.Time);
        System.out.println("Capacity: " + Capacity);
        System.out.println("\n-------------------.--------------------------------------------\n");
        System.out.println("Printed on: " + "\t\t\t" + date);
        System.out.println("\n-------------------------.--------------------------------------\n");
        System.out.println("Please keep the receipt as proof of booking and payment.");
        System.out.println("\n---------------------------------------------------------------");

        //
    }

    public void fromYear() {
        // here we design how the invoive will look like
        Date date = new Date();

        custnumber = rn.nextInt(1000);

        // printing the receipt

        System.out.println(company.toUpperCase() + "\t\t\t\t\t" + "Cust" + custnumber);
        System.out.println("---------------------------------------------------------------\n");
        System.out.println("Name: " + lo.Name);
        System.out.println("Surname: " + lo.Surname);
        System.out.println("Phone number: " + lo.Number);
        System.out.println("Email: " + lo.Email);
        System.out.println("\n-------------------------------------------------------------\n");
        System.out.println("Type: " + "\t" + "Venue: " + "\t" + "Date: " + "\t" + "Time: " + "\t");
        System.out.println("-----------------------------------------------------------------");
        System.out.println(type + "\t" + ye.venue + "\t" + ye.Event_Date + "\t" + ye.Time);
        System.out.println("Capacity: " + Capacity);
        System.out.println("\n---------------------------------------------------------------\n");
        System.out.println("Printed on: " + "\t\t\t" + date);
        System.out.println("\n---------------------------------------------------------------\n");
        System.out.println("Please keep the receipt as proof of booking and payment.");
        System.out.println("\n---------------------------------------------------------------");

        //
    }*/

    public void User() {

        Datahandler dh = new Datahandler();
        List<String> li2 = new ArrayList<>();
         li2 = dh.li;

    }
}