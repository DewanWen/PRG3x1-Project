package Business;
import java.util.*;
import java.util.Random;

public class decision implements Runnable {

    // thread
    public void run() {
        // this is the notification

        System.out.println("-------------------NOTIFICATION!!!-------------------");

        System.out.println(
                "We are currently checking our schedule, please wait for the decision before proceeding to make further bookings");
        System.out.println("\n");

        try {
            Dec();
        } catch (InterruptedException e) {
            System.out.println("Error: " + e.toString());
        }

    }

    //
    public void Dec() throws InterruptedException {

        // delay
        Thread.sleep(5000);

        Integer choice;

        Random rand = new Random();

        choice = rand.nextInt(3);

        // decision will be made here

        switch (choice) {
        case 0:
            System.out.println("The booking has been confirmed, please proceed...");
            Bookings bo = new Bookings();
            bo.ordering();
            break;
        case 1:
            System.out.println(
                    "There is an unconfirmed booking for that day, we will put you on the waiting list. \nWe will contact you with further details");
            Bookings ba = new Bookings();
            ba.ordering();
            break;
        case 2:
            System.out.println(
                    "Unfortunately, we are currently on holiday. \nWe will inform you once we are back in business.");
            Thread.sleep(2000);
            System.exit(0);
            break;
        default:

            // close the program after this part
            System.out.println("We are currently fully booked at the moment. \nWe cannot take any further bookings.");
            Thread.sleep(2000);
            System.exit(0);
            break;
        }
    }

}
