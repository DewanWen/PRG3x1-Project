package Business;

public class Bookings {

    // logic here
    String status = "pending"; // default status
    String Adults_Food;
    String Kids_Food;
    String Desert;

    // the important class
    Food foo = new Food();

    // need a class for the food menu
    public void ordering() {

        // food for adult
        Adults_Food = foo.adultsMenu();

        // kids
        Kids_Food = foo.kidsMenu();

        // desert
        Desert = foo.desrt();

        /*
         * Calculations ca = new Calculations(); ca.pay();
         */

        Printing re = new Printing();
        re.frombaptism();

    }
}
