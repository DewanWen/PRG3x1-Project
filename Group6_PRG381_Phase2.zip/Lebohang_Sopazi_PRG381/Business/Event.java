package Business;
import java.util.Scanner;

public abstract class Event {

    // we add fields here
    String venue;
    String Deco;
    String Event_Date;
    String Theme;
    String Time;
    Integer Capacity;
    Integer numberOfKids;
    Integer numberOfAdults;

    // add a and b to get the capacity of the event
    public abstract Integer totalNumber(Integer a, Integer b);

}
