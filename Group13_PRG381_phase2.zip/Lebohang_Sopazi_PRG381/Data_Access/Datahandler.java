package Data_Access;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import Business.Event;
import Business.Event_selector;

public class Datahandler {
    //// this will populate the database/textfile
    public List<String> databasepopulator = new ArrayList<>();

    public void inPut() throws IOException {
        // this methods writes into database or textfile

        // important objects
        File fl = new File("test.txt");

        // the true in here is to allow append to take place
        FileWriter fw = new FileWriter(fl, true);

        // object that writes into textfile
        PrintWriter pw = new PrintWriter(fw);

        // populating textfile
        // these will be the important fields

        for (String items : databasepopulator) {
            pw.println(items);
        }
        pw.close();
    }

    public void collect(String a, String b, Integer d, String e, String f) throws IOException {
        String items = a + ", " + b + ", " + d + ", " + e + ", " + f;

        databasepopulator.add(items);

        // now we add to the database
        inPut();
    }

    // instance of a list
    public List<String> li = new ArrayList<>();

    // extracts textfile items into a list
    public void coll() throws FileNotFoundException {

        // this class will read data from the text file then compare it with the
        // userinput string
        File file1 = new File("test.txt");

        Scanner sc = new Scanner(file1);

        // then we input into a collection
        // this reads everything in the text
        // we first need the # of lines in the

        while (sc.hasNextLine()) {
            li.add(sc.nextLine());
        }

        // close the file when done
        sc.close();

    }

    // this method compares what is on the list with what the user entered to login

    public void Compare(String NamE) throws FileNotFoundException {
        // this method will then compare what the user entered to login with what is
        // stored in the text file

        // let us get the items from the textfile into a collection
        coll();
        // here we used the regex method
        // items stored into the textfile are not case sensitive

        Pattern pattern = Pattern.compile(li.toString(), Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(NamE);
        boolean matchFound = matcher.find();
        if (matchFound) {
            System.out.println("Login succesfully!");
            System.out.println("\n");

            Event_selector ev = new Event_selector();
            ev.Men();

        } else {
            System.out.println("Login NOT succesfully. Please try again or register an account");
        }
    }
}