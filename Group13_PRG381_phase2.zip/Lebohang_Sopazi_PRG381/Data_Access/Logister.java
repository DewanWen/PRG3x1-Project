package Data_Access;

import java.io.FileNotFoundException;
import java.util.Scanner;
import Business.*;

public class Logister {
    
    public void display() throws FileNotFoundException {
        System.out.println("\n---------------------------------------------------------------\n");
        System.out.println("-------------Welcome to Delicious Catering services-------------");
        System.out.println("\n---------------------------------------------------------------\n");
        System.out.println("Please select any of the following options: ");
        System.out.println("1. Login. \n2. Register. \n3. Exit");

        Scanner sc = new Scanner(System.in);
        Integer choice = sc.nextInt();

        // switch statement here for decision making
        switch (choice) {
            case 1:
                //login
                Log();
                break;
            case 2:
                // register
                Register reg = new Register();
                reg.Details();
                break;
            default:
                System.exit(0);
                break;
        }
    }
    //this is the login method
    public String name;
    public String Passwrd;
    public String Item;

    public void Log() throws FileNotFoundException{

        
        Scanner sc = new Scanner(System.in);

        //name
        System.out.println("Please enter your name: ");
        name = sc.next();
        Printing pr = new Printing();
        pr.extract(name);

        //password
        System.out.println("Please enter your password: ");
        Passwrd = sc.next();

        Item = name+", "+Passwrd;

        Datahandler dh = new Datahandler();
        dh.Compare(Item);

    }
}
