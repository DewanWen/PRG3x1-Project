package Business;

import java.util.Scanner;

public class Birthday extends Event {
    // logic here

    String eventType = "Birthday";

    @Override
    public Integer totalNumber(Integer a, Integer b) {

        // We need toknow the number of kids and adults for catering purposes
        this.numberOfAdults = a;
        this.numberOfKids = b;
        Capacity = numberOfAdults + numberOfKids;

        return Capacity;
    }

    // calculations class instant here
    Calculation ca = new Calculation();

    public void questions() {

        Scanner sn = new Scanner(System.in);
        Scanner se = new Scanner(System.in);

        System.out.println("\n-----------------------------------------\n");

        // date
        System.out.println("When will the event be taking place?");
        System.out.println("Please enter the date (use DD/MM/YYYY): ");
        Event_Date = sn.next();

        // time
        System.out.println("Please enter the time: ");
        Time = sn.next();

        // venue
        System.out.println("Please enter the name (or address) of the venue: ");
        venue = sn.next();

        // number of kids
        System.out.println("Please enter the number of anticipated kids: ");
        numberOfKids = se.nextInt();

        // number of adults
        System.out.println("Please enter the number of anticipated Adults: ");
        numberOfAdults = se.nextInt();

        if (numberOfAdults > 40) {
            System.out.println("\n");
            System.out.println("You qualify for our 15% discount");
            System.out.println("\n");
        }

        String choice;
        Scanner fc = new Scanner(System.in);
        System.out.println("Would you like us to also provide deco for the event");
        System.out.println("Please choose enter Y for Yes or N for No");
        choice = fc.next();

        if (choice.toUpperCase() == "Y") {
            System.out.println("Please enter the theme of the event: ");
            Theme = fc.next();
        } else {
            Theme = "No, thank you. I have this one covered.";
        }

        ca.charges(numberOfAdults, numberOfKids);

        System.out.println("\n-----------------------------------------\n");

        decision de = new decision();
        de.run();

    }

}
