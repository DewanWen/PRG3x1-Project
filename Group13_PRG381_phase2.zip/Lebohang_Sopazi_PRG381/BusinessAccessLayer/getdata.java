package PRG3x1_Project.BusinessAccessLayer;

public interface getdata {
    abstract void getData();
}
